<!DOCTYPE html>
<html lang="cn">
<head>
    <meta charset="UTF-8"/>
    <title>红魔馆网络</title>
    <script>
        function init() {
            if (/order/.test(window.location.hash)) {
                window.location.href = window.location.origin + '/baidu';
                return
            }
            const appUser = localStorage.getItem('app-user')
            if (appUser) {
                let token = JSON.parse(appUser).token
                if (token) {
                    window.location.href = '/baidu'
                }
            }
        }
        init()
    </script>
    <meta name="description" content="红魔馆网络、大陆首选网络加速服务、更稳定、更快、支持Android、iOS、MacOS、Windows、Linux、路由器、节点全解锁Netflix、Tiktok等流媒体服务。">
    <link rel="shortcut icon" href="./favicon.ico">
    <link rel="stylesheet" href="./files/index.min.css">
    <link rel="stylesheet" href="./files/iconfont.css">
    <style>
        @media (max-width: 992px) {
            #lijizhu {
                display: none !important;
            }

            #dlzc {
                display: block !important;
            }
        }
    </style>
</head>

<body>
    <header id="main-header" style="background: #fff" class="header-main header2">
        <div class="container">
            <div class="row">
                <div class="col-sm-12">
                    <nav class="navbar navbar-expand-lg navbar-light">
                        <a class="navbar-brand" href="#">
                            <img class="img-fluid" src="./vite.svg" alt="img">
                        </a>
                        <div class="collapse navbar-collapse" id="navbarSupportedContent"></div>
                        <div class="sub-main">
                            <ul>
                                <li class="d-inline"><a href="/baidu/" class="signup iq-button default iq-btn-round">登录 / 注册</a></li>
                            </ul>
                        </div>
                    </nav>
                </div>
            </div>
        </div>
    </header>
    <!--<div style="height: 60px" class="xh"></div>-->
    <div class="main-content">
        <section class="sc-a2859cd5-0 OUtvL">
            <div class="sc-a2859cd5-1 bBHvAq">
                <div class="sc-a2859cd5-2 ekcZdZ">
                    <rs-mask-wrap style="display: block; overflow: visible; visibility: visible;">
                        <rs-layer id="slider-2-slide-2-layer-0" class="textgyreadventor rs-layer" style="z-index: 8; visibility: visible; text-align: left; line-height: 90px; letter-spacing: 0px; font-weight: 700; font-size: 70px; border-color: rgb(94, 114, 144); border-style: none; margin: 0px; border-radius: 0px; padding: 0px; color: rgb(0, 123, 252); text-decoration: none; white-space: nowrap; width: auto; height: auto; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">
                            红魔馆网络
                        </rs-layer>
                    </rs-mask-wrap>
                    <rs-mask-wrap style="display: block; visibility: visible; overflow: visible;">
                        <rs-layer id="slider-2-slide-2-layer-1" class="textgyreadventor rs-layer" data-type="text" style="z-index: 9; visibility: visible; text-align: left; line-height: 55px; letter-spacing: 0px; font-weight: 700; font-size: 40px; border-color: rgb(94, 114, 144); border-style: none; margin: 0px; border-radius: 0px; padding: 0px; color: rgb(20, 33, 73); text-decoration: none; white-space: nowrap; width: auto; height: auto; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;">
                            大陆首选网络加速服务<br>更稳定、更快
                        </rs-layer>
                    </rs-mask-wrap>
                    <rs-mask-wrap style="display: block; overflow: visible; visibility: visible;margin-top: 10px">
                        <rs-layer id="slider-2-slide-2-layer-2" style="z-index: 10; visibility: visible; text-align: left; line-height: 35px; letter-spacing: 0px; font-weight: 400; font-size: 20px; border-color: rgb(94, 114, 144); border-style: none; margin: 0px; border-radius: 0px; padding: 0px; color: rgb(94, 114, 144); text-decoration: none; white-space: nowrap; width: auto; height: auto; min-height: 0px; min-width: 0px; max-height: none; max-width: none; opacity: 1; transform: matrix3d(1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1); transform-origin: 50% 50% 0px;" class="rs-layer" data-idcheck="true">
                            支持安卓、ios、windows、linux等不同平台设备<br>节点全解锁奈飞、chatgpt等流媒体服务<br>畅享互联网、从红魔馆网络 Cloud开始。
                        </rs-layer>
                    </rs-mask-wrap>

                    <div class="sc-a2859cd5-3 hMuEGM">
                        <a id="slider-2-slide-2-layer-3" class="rs-layer iq-button iq-btn-round rev-btn" href="/baidu/" target="_self" style="z-index:11;background-color:#007bfc;text-transform:capitalize;display:flex;align-items: center;justify-content: center">
                            <span id="lijizhu">立即使用</span>
                            <span id="dlzc" style="display: none">登录/注册</span>
                        </a>
                    </div>
                </div>
                <div class="sc-a2859cd5-4 jvYRwl" style="width:100%">
                    <img src="./files/hero_da46938cdf.png">
                </div>
            </div>
        </section>

        <section class="iq-fancy-box-section">
            <img src="./files/shape1.png" class="img-fluid shape-left" alt="QLOUD">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center iq-title-box iq-title-default iq-title-box-2 wow fadeInUp" data-wow-duration="0.6s">
                            <div class="iq-title-icon">
                            </div>
                            <h2 class="iq-title">支持主流订阅软件</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 mb-lg-0 mb-5">
                        <div class="iq-process iq-process-step-style-6 text-center wow fadeInUp" data-wow-duration="0.6s">
                            <div class="iq-process-step">
                                <img class="iq-before-img img-fluid" src="./files/arrow.png" alt="arrow-img">
                                <div class="iq-step-content">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/shadowrocket.png&#39;) no-repeat center;background-size: contain; margin: 0 auto;"></div>
                                </div>
                                <div class="iq-step-text-area">
                                    <h4 class="iq-step-title mt-3 mb-3">Shadowrocket</h4>
                                    <span class="iq-step-desc">适用于iPhone/iPad的基于规则的代理实用程序客户端。</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 mb-lg-0 mb-5">
                        <div class="iq-process iq-process-step-style-6 text-center wow fadeInUp" data-wow-duration="1.2s">
                            <div class="iq-process-step">
                                <img class="iq-before-img img-fluid" src="./files/arrow.png" alt="arrow-img">
                                <div class="iq-step-content">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/clash.png&#39;) no-repeat center;background-size: contain; margin: 0 auto;"></div>
                                </div>
                                <div class="iq-step-text-area">
                                    <h4 class="iq-step-title mt-3 mb-3">ClashX</h4>
                                    <span class="iq-step-desc">ClashX是MacOS系统即Windows系统下的代理软件客户端</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4">
                        <div class="iq-process iq-process-step-style-6 text-center wow fadeInUp" data-wow-duration="1.8s">
                            <div class="iq-process-step">
                                <div class="iq-step-content">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/v2rayng.png&#39;) no-repeat center;background-size: contain; margin: 0 auto;"></div>
                                </div>
                                <div class="iq-step-text-area">
                                    <h4 class="iq-step-title mt-3 mb-3">V2rayng</h4>
                                    <span class="iq-step-desc">一款适用于Android的V2Ray客户端。</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="iq-pb-70">
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center iq-title-box iq-title-default iq-title-box-2 wow fadeInUp">
                            <div class="iq-title-icon">
                            </div>
                            <h2 class="iq-title">超强技术实力与基础设施</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-12 mb-lg-0 mb-4">
                        <div class="row">
                            <div class="col-lg-12 col-md-6">
                                <div class="iq-icon-box iq-icon-box-style-8  text-center wow fadeInLeft">
                                    <div class="icon-box-img">
                                        <div style="width: 70px; height: 73px; background: url(&#39;./files/img/index.png&#39;) no-repeat 0 -278px; margin: 0 auto 1rem;"></div>
                                    </div>
                                    <div class="icon-box-content">
                                        <h5 class="icon-box-title">先进隧道技术</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6">
                                <div class="iq-icon-box iq-icon-box-style-8  text-center wow fadeInLeft">
                                    <div class="icon-box-img">
                                        <div style="width: 70px; height: 73px; background: url(&#39;./files/img/index.png&#39;) no-repeat -277px -277px; margin: 0 auto 1rem;"></div>
                                    </div>
                                    <div class="icon-box-content">
                                        <h5 class="icon-box-title">智能接入点分配</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-md-12 mb-lg-0 mb-4">
                        <div class="iq-fancy-box iq-resorces  text-left active wow fadeInUp ">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <img src="./files/other.png" class="img-fluid" title="img1" alt="qloud">
                                </div>
                                <div class="media-body">
                                    <h5 class="iq-fancy-title">可靠性、安全性和性能保证</h5>
                                    <p class="fancy-box-content mb-0">
                                        我们在全球范围建立了多个加速节点，以方便个人用户解决网络限制、保护隐私、提升网络安全等问题。在网络上传输的数据包采用了流加密技术，保障安全的同时，大大提高了传输速度。我们以优质资源与冗余备份确保其畅通可靠，为您提供快速稳定的国际网络接入。</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-12">
                        <div class="row">
                            <div class="col-lg-12 col-md-6">
                                <div class="iq-icon-box iq-icon-box-style-8  text-center  wow fadeInRight">
                                    <div class="icon-box-img">
                                        <div style="width: 70px; height: 73px; background: url(&#39;./files/img/index.png&#39;) no-repeat -130px -268px; margin: 0 auto 1rem;"></div>
                                    </div>
                                    <div class="icon-box-content">
                                        <h5 class="icon-box-title">全球自建数据中心</h5>
                                    </div>
                                </div>
                            </div>
                            <div class="col-lg-12 col-md-6">
                                <div class="iq-icon-box iq-icon-box-style-8  text-center wow fadeInRight">
                                    <div class="icon-box-img">
                                        <div style="width: 70px; height: 73px; background: url(&#39;./files/img/index.png&#39;) no-repeat 0 -278px; margin: 0 auto 1rem;"></div>
                                    </div>
                                    <div class="icon-box-content">
                                        <h5 class="icon-box-title">高冗余保障</h5>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section>
            <div class="container">
                <div class="row">
                    <div class="col-lg-12">
                        <div class="text-center iq-title-box iq-title-default iq-title-box-2 wow fadeInUp" data-wow-duration="0.6s">
                            <div class="iq-title-icon">
                            </div>
                            <h2 class="iq-title">为您量身定制的服务</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="iq-fancy-box-list iq-fancy-box-list-1  text-left iq-shadow wow fadeInUp" data-wow-duration="0.6s">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/index.png&#39;) no-repeat 0 -356px;"></div>
                                </div>
                                <div class="iq-fancy-details">
                                    <h4 class="iq-fancy-title">高速稳定线路</h4>
                                    <div class="special-content">
                                        <p class="fancy-box-content">高速传输，极限本地带宽体验</p>
                                    </div>
                                    <div class="iq-list  iq-one-column">
                                        <ul class="iq-list-with-icon">
                                            <li><i class="icon ga checkcircle"></i>全球数百加速网络连接服务点</li>
                                            <li><i class="icon ga checkcircle"></i>六年累积经验，创新完美架构</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="iq-fancy-box-list iq-fancy-box-list-1  text-left iq-shadow wow fadeInUp" data-wow-duration="0.9s">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/index.png&#39;) no-repeat -135px -356px;"></div>
                                </div>
                                <div class="iq-fancy-details">
                                    <h4 class="iq-fancy-title">简易操作配置</h4>
                                    <div class="special-content">
                                        <p class="fancy-box-content">全系客户端支持 简单操作配置</p>
                                    </div>
                                    <div class="iq-list  iq-one-column">
                                        <ul class="iq-list-with-icon">
                                            <li><i class="icon ga checkcircle"></i>简单易用的适配客户端</li>
                                            <li><i class="icon ga checkcircle"></i>完善的售后服务 丰富的社区内容</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="iq-fancy-box-list iq-fancy-box-list-1  text-left iq-shadow wow fadeInUp" data-wow-duration="1.2s">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/index.png&#39;) no-repeat -252px -356px;"></div>
                                </div>
                                <div class="iq-fancy-details">
                                    <h4 class="iq-fancy-title">运营商智能优化</h4>
                                    <div class="special-content">
                                        <p class="fancy-box-content">从入口到落地 精选优质运营商</p>
                                    </div>
                                    <div class="iq-list  iq-one-column">
                                        <ul class="iq-list-with-icon">
                                            <li><i class="icon ga checkcircle"></i>多层线路优化</li>
                                            <li><i class="icon ga checkcircle"></i>负载均衡设定</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="iq-fancy-box-list iq-fancy-box-list-1  text-left iq-shadow wow fadeInUp" data-wow-duration="1.5s">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/index.png&#39;) no-repeat 0 -472px;"></div>
                                </div>
                                <div class="iq-fancy-details">
                                    <h4 class="iq-fancy-title">定制服务售后</h4>
                                    <div class="special-content">
                                        <p class="fancy-box-content">根据需求提供满足特定需求的服务</p>
                                    </div>
                                    <div class="iq-list  iq-one-column">
                                        <ul class="iq-list-with-icon">
                                            <li><i class="icon ga checkcircle"></i>尊重用户需求</li>
                                            <li><i class="icon ga checkcircle"></i>用心聆听 不断优化</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="iq-fancy-box-list iq-fancy-box-list-1  text-left iq-shadow wow fadeInUp" data-wow-duration="1.8s">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/index.png&#39;) no-repeat -122px -472px;"></div>
                                </div>
                                <div class="iq-fancy-details">
                                    <h4 class="iq-fancy-title">安全稳定保障</h4>
                                    <div class="special-content">
                                        <p class="fancy-box-content">专人系统维护 多重数据备份
                                        </p>
                                    </div>
                                    <div class="iq-list  iq-one-column">
                                        <ul class="iq-list-with-icon">
                                            <li><i class="icon ga checkcircle"></i>企业级部署服务</li>
                                            <li><i class="icon ga checkcircle"></i>安全高效的加密技术</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="iq-fancy-box-list iq-fancy-box-list-1  text-left iq-shadow wow fadeInUp" data-wow-duration="2.1s">
                            <div class="iq-fancy-box-content">
                                <div class="iq-img-area">
                                    <div style="width: 110px; height: 100px; background: url(&#39;./files/img/index.png&#39;) no-repeat -267px -472px;"></div>
                                </div>
                                <div class="iq-fancy-details">
                                    <h4 class="iq-fancy-title">丰富社区服务</h4>
                                    <div class="special-content">
                                        <p class="fancy-box-content">集成社区系统 完善学习文档</p>
                                    </div>
                                    <div class="iq-list  iq-one-column">
                                        <ul class="iq-list-with-icon">
                                            <li><i class="icon ga checkcircle"></i>多元用户交流平台</li>
                                            <li><i class="icon ga checkcircle"></i>内容丰富 文档完善</li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <section class="pt-0">
            <div class="container">
                <div class="row">
                    <div class="col-lg-6 col-sm-12 mb-lg-0 mb-5">
                        <div class=" text-left iq-title-box iq-title-default iq-title-box-2 mt-lg-5 pt-lg-5">
                            <h2 class="iq-title">解锁流媒体<br>观赏和聆听优质的内容 </h2>
                            <p class="iq-title-desc">通过红魔馆网络的服务，可以观看包括 Netflix、Hulu、HBO、TVB、Happyon、AbemaTV
                                等在内的多种流媒体视频，聆听包括 Spotify、Pandora 等在内的流媒体音乐。</p>
                        </div>
                    </div>
                    <div class="col-lg-6 col-sm-12">
                        <img src="./files/liumeiti.png" class="img-fluid" alt="qloud">
                    </div>
                </div>
            </div>
        </section>
    </div>
    <footer id="contact" class="iq-over-dark-90">
        <div class="copyright-footer">
            <div class="container">
                <div class="pt-3 pb-3">
                    <div class="row justify-content-between">
                        <div class="col-12 text-center">
                            <span class="copyright">Copyright 2024红魔馆网络All Rights Reserved.</span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </footer>
</body>
</html>