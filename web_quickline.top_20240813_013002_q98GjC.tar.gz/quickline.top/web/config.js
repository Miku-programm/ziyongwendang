window._config = {
    color: '',              // 主题配色 (16进制颜色代码，默认为蓝色
    crisp: '',              // Crisp ID
    chat_js: '',            // 在线客服JS链接 (与Crisp二选一
    apiUrl: 'https://v2b.spaceslio.com',
    login_title: 'Vuexy',   // 登录页标题
    download: {             // 客户端下载地址
        window: '',
        android: '',
        ios: '',
        macos: '',
    }
}

if (window._config['color']) {
    const root = document.documentElement;
    root.style.setProperty('--theme-color', window._config['color']);
}


if (window._config['chat_js']) {
    const scriptElement = document.createElement('script');
    scriptElement.src = window._config['chat_js']
    scriptElement.async = true;
    document.head.appendChild(scriptElement);
}

if (window._config['crisp']) {
    window.$crisp = [];
    window.CRISP_WEBSITE_ID = window._config['crisp']; // 填写 Crisp ID
    (function () {
      d = document;
      s = d.createElement("script");
      s.src = "https://client.crisp.chat/l.js";
      s.async = 1;
      d.getElementsByTagName("head")[0].appendChild(s);
    })();
}
